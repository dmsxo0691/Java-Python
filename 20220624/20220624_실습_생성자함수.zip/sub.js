function student(name, height, city, weight, classNumber){
    this.name = name;
    this.height = height;
    this.city = city;
    this.weight = weight;
    this.classNumber = classNumber;

    this.eat = function(){
        return (name + name +'우걱우걱');
    }
    this.shit = function(){
        return (name + name +'...!');
    }
    this.home = function(){
        return (name + name + city +'(으)로 간다.')
    }
    this.school = function(){
        return (name + name + '학교로 간다.')
    }
    this.information = function(){
        console.log('나는'+this.name+' 나이는'+this.age+' 사는 곳은'+this.city+' 키는'+this.height+' 학번은'+this.classNumber);
    }
}


const student1 = new student('태용', 180, '양주', 100, 16);
const student2 = new student('소리', 170, '서울', 70, 08);
const student3 = new student('마태', 175, '남한산성', 90, 14);
console.log(student1.eat());
console.log(student2.eat());
console.log(student3.eat());
console.log(student1.shit());
console.log(student2.shit());
console.log(student3.shit());
console.log(student1.home());
console.log(student2.home());
console.log(student3.home());
console.log(student1.school());
console.log(student2.school());
console.log(student3.school());
console.log(student1.information());
console.log(student2.information());
console.log(student3.information());